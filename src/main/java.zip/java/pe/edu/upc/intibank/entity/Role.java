package pe.edu.upc.intibank.entity;

public enum Role {
    USER,
    ADMIN
}
