package pe.edu.upc.intibank.service;


import pe.edu.upc.intibank.model.authentication.UserProfileResponseModel;

public interface UserService {
    UserProfileResponseModel getUserProfile();
}
