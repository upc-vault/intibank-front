package pe.edu.upc.intibank.entity;

public enum TransactionType {
    DEPOSIT,
    WITHDRAW
}
